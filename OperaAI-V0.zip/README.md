# OperaAI V0
Demo front-end del progetto OperaAI.

Apri `index.html` nel browser. Questa versione è volutamente senza API AI: simula il flusso e serve a validare design e UX.

Prossimi step: backend sicuro, API AI reale, database, login, upload documenti, email, pagamenti e pubblicazione online.
